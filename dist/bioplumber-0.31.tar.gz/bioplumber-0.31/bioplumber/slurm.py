import rich


class SlurmTaskManager:
    pass
    def view_slurm_queue(self):
        pass